package net.withered.tolm.api;

import net.minecraft.class_1291;
import net.minecraft.class_4081;

public abstract class PersistentEffect extends class_1291 {

    protected PersistentEffect(class_4081 category, int color) {
        super(category, color);
    }

    public boolean persistsThroughMilk() {
        return true;
    }

    public boolean persistsThroughTotem() {
        return true;
    }

    public boolean persistsThroughDeath() {
        return true;
    }
}