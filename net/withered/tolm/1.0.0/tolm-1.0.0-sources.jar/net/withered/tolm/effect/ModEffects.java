package net.withered.tolm.effect;

import net.minecraft.class_1291;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4081;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.withered.tolm.ThatOneLibraryMod;

public class ModEffects {
    public static final class_6880<class_1291> DEBUG = registerStatusEffect("debug",
            new DebugEffect(class_4081.field_18273, 0x36ebab));


    private static class_6880<class_1291> registerStatusEffect(String name, class_1291 statusEffect) {
        return class_2378.method_47985(class_7923.field_41174, class_2960.method_60655(ThatOneLibraryMod.MOD_ID, name), statusEffect);
    }

    public static void init() {
    }
}