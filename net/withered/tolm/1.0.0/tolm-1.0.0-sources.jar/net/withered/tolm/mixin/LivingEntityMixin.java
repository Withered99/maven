package net.withered.tolm.mixin;

import net.minecraft.class_1282;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1805;
import net.minecraft.class_3222;
import net.minecraft.class_6880;
import net.withered.tolm.ThatOneLibraryMod;
import net.withered.tolm.api.PersistentEffect;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin {

    @Shadow @Final private Map<class_6880<class_1291>, class_1293> activeStatusEffects;
    @Shadow protected abstract void onStatusEffectRemoved(class_1293 effect);

    @Unique
    private static final ThreadLocal<Boolean> IS_TOTEM_CLEAR = ThreadLocal.withInitial(() -> false);

    @Inject(method = "tryUseTotem", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;clearStatusEffects()Z"))
    private void onTotemPreClear(class_1282 source, CallbackInfoReturnable<Boolean> cir) {
        IS_TOTEM_CLEAR.set(true);
    }

    @Inject(method = "tryUseTotem", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;clearStatusEffects()Z", shift = At.Shift.AFTER))
    private void onTotemPostClear(class_1282 source, CallbackInfoReturnable<Boolean> cir) {
        IS_TOTEM_CLEAR.set(false);
    }

    @Inject(method = "clearStatusEffects", at = @At("HEAD"), cancellable = true)
    private void onClearStatusEffects(CallbackInfoReturnable<Boolean> cir) {
        class_1309 self = (class_1309) (Object) this;
        if (self.method_37908().field_9236) {
            return;
        }

        boolean isTotem = IS_TOTEM_CLEAR.get();
        boolean isMilk = self.method_6030().method_7909() instanceof class_1805;
        boolean isDying = self.method_29504();

        if (!isTotem && !isMilk && !isDying) {
            return;
        }
        boolean removedAny = false;
        Iterator<Map.Entry<class_6880<class_1291>, class_1293>> iterator = this.activeStatusEffects.entrySet().iterator();

        while (iterator.hasNext()) {
            Map.Entry<class_6880<class_1291>, class_1293> entry = iterator.next();
            class_1291 effect = entry.getKey().comp_349();
            if (effect instanceof PersistentEffect persistent) {
                if ((isTotem && persistent.persistsThroughTotem()) || (isMilk && persistent.persistsThroughMilk()) || (isDying && persistent.persistsThroughDeath())) {
                    continue;
                }
            }
            class_1293 instance = entry.getValue();
            iterator.remove();
            this.onStatusEffectRemoved(instance);
            removedAny = true;
        }
        cir.setReturnValue(removedAny);
    }
    @Inject(method = "onDeath", at = @At("HEAD"))
    private void onDeathHead(class_1282 damageSource, CallbackInfo ci) {
        class_1309 self = (class_1309) (Object) this;
        if (self.method_37908().field_9236) {
            return;
        }

        if (self instanceof class_3222 player) {
            List<class_1293> toKeep = new ArrayList<>();
            for (class_1293 instance : player.method_6026()) {
                if (instance.method_5579().comp_349() instanceof PersistentEffect persistent && persistent.persistsThroughDeath()) {
                    toKeep.add(new class_1293(instance));
                }
            }
            if (!toKeep.isEmpty()) {
                ThatOneLibraryMod.SAVED_EFFECTS.put(player.method_5667(), toKeep);
            }
        }
    }
}