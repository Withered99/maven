package net.withered.tolm;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1293;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.withered.tolm.api.PersistentEffect;
import net.withered.tolm.effect.ModEffects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class ThatOneLibraryMod implements ModInitializer {
    public static final String MOD_ID = "tolm";
    public static final Map<UUID, List<class_1293>> SAVED_EFFECTS = new ConcurrentHashMap<>();
    boolean isDev = FabricLoader.getInstance().isDevelopmentEnvironment();

    @Override
    public void onInitialize() {
        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, damageSource, damageAmount) -> {
            if (entity instanceof class_3222 player) {
                List<class_1293> toKeep = new ArrayList<>();
                for (class_1293 instance : player.method_6026()) {
                    if (instance.method_5579().comp_349() instanceof PersistentEffect persistent
                            && persistent.persistsThroughDeath()) {
                        toKeep.add(new class_1293(instance));
                    }
                }
                if (!toKeep.isEmpty()) {
                    SAVED_EFFECTS.put(player.method_5667(), toKeep);
                }
            }
            return true;
        });
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            if (!alive) {
                List<class_1293> saved = SAVED_EFFECTS.remove(oldPlayer.method_5667());
                if (saved != null) {
                    for (class_1293 instance : saved) {
                        newPlayer.method_6092(new class_1293(instance));
                    }
                }
            }
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            SAVED_EFFECTS.remove(handler.field_14140.method_5667());
        });

        if (isDev) {
            ModEffects.init();
        }
    }
    public static class_2960 id(String path) {
        return class_2960.method_60655(MOD_ID, path);
    }
}
