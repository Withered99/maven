package net.withered.tolm.effect;

import net.minecraft.class_4081;
import net.withered.tolm.api.PersistentEffect;

public class DebugEffect extends PersistentEffect {
    protected DebugEffect(class_4081 category, int color) {
        super(category, color);
    }
}
