package net.withered.artisansandmillwork;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_3929;
import net.withered.artisansandmillwork.client.gui.screens.inventory.MillingTableScreen;
import net.withered.artisansandmillwork.inventory.ModMenuTypes;

public class ArtisansAndMillworkClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        class_3929.method_17542(ModMenuTypes.MILLING_TABLE, MillingTableScreen::new);
    }
}
