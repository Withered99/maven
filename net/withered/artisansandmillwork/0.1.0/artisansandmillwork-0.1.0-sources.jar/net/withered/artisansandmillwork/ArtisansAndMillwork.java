package net.withered.artisansandmillwork;

import net.fabricmc.api.ModInitializer;
import net.minecraft.class_2960;
import net.withered.artisansandmillwork.block.ModBlocks;
import net.withered.artisansandmillwork.inventory.ModMenuTypes;
import net.withered.artisansandmillwork.item.ModItemGroups;
import net.withered.artisansandmillwork.item.crafting.ModRecipeSerializers;
import net.withered.artisansandmillwork.item.crafting.ModRecipeTypes;

public class ArtisansAndMillwork implements ModInitializer {
	public static final String MOD_ID = "artisansandmillwork";

	@Override
	public void onInitialize() {
        ModBlocks.init();
        ModMenuTypes.init();
        ModRecipeTypes.init();
        ModRecipeSerializers.init();
        ModItemGroups.init();
	}

	public static class_2960 id(String path) {
		return class_2960.method_60655(MOD_ID, path);
	}
}
