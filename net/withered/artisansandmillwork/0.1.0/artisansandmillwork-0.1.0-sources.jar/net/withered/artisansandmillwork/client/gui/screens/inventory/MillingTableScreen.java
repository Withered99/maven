package net.withered.artisansandmillwork.client.gui.screens.inventory;

import net.minecraft.class_1109;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_3532;
import net.minecraft.class_465;
import net.minecraft.class_8786;
import net.withered.artisansandmillwork.inventory.MillingTableMenu;
import net.withered.artisansandmillwork.item.crafting.MillingTableRecipe;

import java.util.List;

public class MillingTableScreen extends class_465<MillingTableMenu> {
    private static final class_2960 SCROLLER_SPRITE = class_2960.method_60656("container/stonecutter/scroller");
    private static final class_2960 SCROLLER_DISABLED_SPRITE = class_2960.method_60656("container/stonecutter/scroller_disabled");
    private static final class_2960 RECIPE_SELECTED_SPRITE = class_2960.method_60656("container/stonecutter/recipe_selected");
    private static final class_2960 RECIPE_HIGHLIGHTED_SPRITE = class_2960.method_60656("container/stonecutter/recipe_highlighted");
    private static final class_2960 RECIPE_SPRITE = class_2960.method_60656("container/stonecutter/recipe");
    private static final class_2960 BG_LOCATION = class_2960.method_60656("textures/gui/container/stonecutter.png");

    private float scrollOffs;
    private boolean scrolling;
    private int startIndex;
    private boolean displayRecipes;

    public MillingTableScreen(MillingTableMenu menu, class_1661 playerInventory, class_2561 title) {
        super(menu, playerInventory, title);
        menu.registerUpdateListener(this::containerChanged);
        --this.field_25268;
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        super.method_25394(guiGraphics, mouseX, mouseY, partialTick);
        this.method_2380(guiGraphics, mouseX, mouseY);
    }

    @Override
    protected void method_2389(class_332 guiGraphics, float partialTick, int mouseX, int mouseY) {
        int i = this.field_2776;
        int j = this.field_2800;
        guiGraphics.method_25302(BG_LOCATION, i, j, 0, 0, this.field_2792, this.field_2779);
        int k = (int) (41.0F * this.scrollOffs);
        class_2960 scroller = this.isScrollBarActive() ? SCROLLER_SPRITE : SCROLLER_DISABLED_SPRITE;
        guiGraphics.method_52706(scroller, i + 119, j + 15 + k, 12, 15);
        int l = this.field_2776 + 52;
        int m = this.field_2800 + 14;
        int n = this.startIndex + 12;
        this.renderButtons(guiGraphics, mouseX, mouseY, l, m, n);
        this.renderRecipes(guiGraphics, l, m, n);
    }

    @Override
    protected void method_2380(class_332 guiGraphics, int x, int y) {
        super.method_2380(guiGraphics, x, y);
        if (this.displayRecipes) {
            int i = this.field_2776 + 52;
            int j = this.field_2800 + 14;
            int k = this.startIndex + 12;
            List<class_8786<MillingTableRecipe>> list = this.field_2797.getRecipes();

            for (int l = this.startIndex; l < k && l < this.field_2797.getNumRecipes(); ++l) {
                int m = l - this.startIndex;
                int n = i + m % 4 * 16;
                int o = j + m / 4 * 18 + 2;
                if (x >= n && x < n + 16 && y >= o && y < o + 18) {
                    guiGraphics.method_51446(this.field_22793, list.get(l).comp_1933().method_8110(this.field_22787.field_1687.method_30349()), x, y);
                }
            }
        }
    }

    private void renderButtons(class_332 guiGraphics, int mouseX, int mouseY, int x, int y, int lastVisibleElementIndex) {
        for (int i = this.startIndex; i < lastVisibleElementIndex && i < this.field_2797.getNumRecipes(); ++i) {
            int j = i - this.startIndex;
            int k = x + j % 4 * 16;
            int l = j / 4;
            int m = y + l * 18 + 2;
            class_2960 sprite;
            if (i == this.field_2797.getSelectedRecipeIndex()) {
                sprite = RECIPE_SELECTED_SPRITE;
            } else if (mouseX >= k && mouseY >= m && mouseX < k + 16 && mouseY < m + 18) {
                sprite = RECIPE_HIGHLIGHTED_SPRITE;
            } else {
                sprite = RECIPE_SPRITE;
            }
            guiGraphics.method_52706(sprite, k, m - 1, 16, 18);
        }
    }

    private void renderRecipes(class_332 guiGraphics, int x, int y, int startIndex) {
        List<class_8786<MillingTableRecipe>> list = this.field_2797.getRecipes();
        for (int i = this.startIndex; i < startIndex && i < this.field_2797.getNumRecipes(); ++i) {
            int j = i - this.startIndex;
            int k = x + j % 4 * 16;
            int l = j / 4;
            int m = y + l * 18 + 2;
            guiGraphics.method_51427(list.get(i).comp_1933().method_8110(this.field_22787.field_1687.method_30349()), k, m);
        }
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        this.scrolling = false;
        if (this.displayRecipes) {
            int i = this.field_2776 + 52;
            int j = this.field_2800 + 14;
            int k = this.startIndex + 12;

            for (int l = this.startIndex; l < k; ++l) {
                int m = l - this.startIndex;
                double d = mouseX - (double) (i + m % 4 * 16);
                double e = mouseY - (double) (j + m / 4 * 18);
                if (d >= 0.0 && e >= 0.0 && d < 16.0 && e < 18.0 && this.field_2797.method_7604(this.field_22787.field_1724, l)) {
                    class_310.method_1551().method_1483().method_4873(class_1109.method_4758(class_3417.field_17711, 1.0F));
                    this.field_22787.field_1761.method_2900(this.field_2797.field_7763, l);
                    return true;
                }
            }

            i = this.field_2776 + 119;
            j = this.field_2800 + 9;
            if (mouseX >= (double) i && mouseX < (double) (i + 12) && mouseY >= (double) j && mouseY < (double) (j + 54)) {
                this.scrolling = true;
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (this.scrolling && this.isScrollBarActive()) {
            int i = this.field_2800 + 14;
            int j = i + 54;
            this.scrollOffs = ((float) mouseY - (float) i - 7.5F) / ((float) (j - i) - 15.0F);
            this.scrollOffs = class_3532.method_15363(this.scrollOffs, 0.0F, 1.0F);
            this.startIndex = (int) ((double) (this.scrollOffs * (float) this.getOffscreenRows()) + 0.5) * 4;
            return true;
        }
        return super.method_25403(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (this.isScrollBarActive()) {
            int i = this.getOffscreenRows();
            float f = (float) scrollY / (float) i;
            this.scrollOffs = class_3532.method_15363(this.scrollOffs - f, 0.0F, 1.0F);
            this.startIndex = (int) ((double) (this.scrollOffs * (float) i) + 0.5) * 4;
        }
        return true;
    }

    private boolean isScrollBarActive() {
        return this.displayRecipes && this.field_2797.getNumRecipes() > 12;
    }

    protected int getOffscreenRows() {
        return (this.field_2797.getNumRecipes() + 4 - 1) / 4 - 3;
    }

    private void containerChanged() {
        this.displayRecipes = this.field_2797.hasInputItem();
        if (!this.displayRecipes) {
            this.scrollOffs = 0.0F;
            this.startIndex = 0;
        }
    }
}
