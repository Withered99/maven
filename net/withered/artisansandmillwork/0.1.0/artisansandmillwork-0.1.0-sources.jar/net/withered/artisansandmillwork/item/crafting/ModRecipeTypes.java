package net.withered.artisansandmillwork.item.crafting;

import net.minecraft.class_1860;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_7923;
import net.withered.artisansandmillwork.ArtisansAndMillwork;

public class ModRecipeTypes {
    public static final class_3956<MillingTableRecipe> MILLING = register("milling");

    private static <T extends class_1860<?>> class_3956<T> register(String name) {
        class_2960 id = class_2960.method_60655(ArtisansAndMillwork.MOD_ID, name);
        return class_2378.method_10230(class_7923.field_41188, id, new class_3956<T>() {
            @Override
            public String toString() {
                return id.toString();
            }
        });
    }

    public static void init() {}
}
