package net.withered.artisansandmillwork.block.custom;

import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2465;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;

public class BeamBlock extends class_2465 {
    protected static final class_265 Y_SHAPE = class_2248.method_9541(5.0, 0.0, 5.0, 11.0, 16.0, 11.0);
    protected static final class_265 X_SHAPE = class_2248.method_9541(0.0, 5.0, 5.0, 16.0, 11.0, 11.0);
    protected static final class_265 Z_SHAPE = class_2248.method_9541(5.0, 5.0, 0.0, 11.0, 11.0, 16.0);

    public BeamBlock(class_2251 properties) {
        super(properties);
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return switch (state.method_11654(field_11459)) {
            case field_11048 -> X_SHAPE;
            case field_11051 -> Z_SHAPE;
            default -> Y_SHAPE;
        };
    }
}
