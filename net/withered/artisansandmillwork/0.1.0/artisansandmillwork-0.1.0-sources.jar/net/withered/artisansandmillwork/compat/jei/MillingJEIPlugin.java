package net.withered.artisansandmillwork.compat.jei;

import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.registration.IRecipeCatalystRegistration;
import mezz.jei.api.registration.IRecipeCategoryRegistration;
import mezz.jei.api.registration.IRecipeRegistration;
import net.minecraft.class_1799;
import net.minecraft.class_1863;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_8786;
import net.withered.artisansandmillwork.ArtisansAndMillwork;
import net.withered.artisansandmillwork.block.ModBlocks;
import net.withered.artisansandmillwork.item.crafting.MillingTableRecipe;
import net.withered.artisansandmillwork.item.crafting.ModRecipeTypes;

import java.util.List;

@JeiPlugin
public class MillingJEIPlugin implements IModPlugin {
    @Override
    public class_2960 getPluginUid() {
        return class_2960.method_60655(ArtisansAndMillwork.MOD_ID, "jei_plugin");
    }

    @Override
    public void registerCategories(IRecipeCategoryRegistration registration) {
        registration.addRecipeCategories(new MillingRecipeCategory(registration.getJeiHelpers().getGuiHelper()));
    }

    @Override
    public void registerRecipes(IRecipeRegistration registration) {
        assert class_310.method_1551().field_1687 != null;
        class_1863 recipeManager = class_310.method_1551().field_1687.method_8433();

        List<MillingTableRecipe> millingRecipes = recipeManager
                .method_30027(ModRecipeTypes.MILLING)
                .stream()
                .map(class_8786::comp_1933)
                .toList();

        registration.addRecipes(MillingRecipeCategory.MILLING_TYPE, millingRecipes);
    }

    @Override
    public void registerRecipeCatalysts(IRecipeCatalystRegistration registration) {
        registration.addRecipeCatalyst(new class_1799(ModBlocks.MILLING_TABLE), MillingRecipeCategory.MILLING_TYPE);
    }
}
