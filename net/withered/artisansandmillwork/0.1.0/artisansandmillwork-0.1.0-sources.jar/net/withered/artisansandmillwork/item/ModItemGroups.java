package net.withered.artisansandmillwork.item;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.withered.artisansandmillwork.ArtisansAndMillwork;
import net.withered.artisansandmillwork.block.ModBlocks;

public class ModItemGroups {
    public static final class_1761 ARTISANS_AND_MILLWORK_GROUP = class_2378.method_10230(
            class_7923.field_44687,
            class_2960.method_60655(ArtisansAndMillwork.MOD_ID, "artisans_and_millwork"),
            FabricItemGroup.builder()
                    .method_47321(class_2561.method_43471("itemgroup.artisansandmillwork.artisans_and_millwork"))
                    .method_47320(() -> new class_1799(ModBlocks.MILLING_TABLE))
                    .method_47317((displayContext, entries) -> {
                        entries.method_45421(ModBlocks.MILLING_TABLE);
                        entries.method_45421(ModBlocks.OAK_BEAM);
                        entries.method_45421(ModBlocks.SPRUCE_BEAM);
                        entries.method_45421(ModBlocks.BIRCH_BEAM);
                        entries.method_45421(ModBlocks.JUNGLE_BEAM);
                        entries.method_45421(ModBlocks.ACACIA_BEAM);
                        entries.method_45421(ModBlocks.DARK_OAK_BEAM);
                        entries.method_45421(ModBlocks.MANGROVE_BEAM);
                        entries.method_45421(ModBlocks.CHERRY_BEAM);
                        entries.method_45421(ModBlocks.BAMBOO_BEAM);
                        entries.method_45421(ModBlocks.CRIMSON_BEAM);
                        entries.method_45421(ModBlocks.WARPED_BEAM);
                    })
                    .method_47324()
    );
    public static void init() {
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(entries -> {
            entries.addAfter(class_2246.field_16335, ModBlocks.MILLING_TABLE);
        });
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40195).register(entries -> {
            entries.addAfter(class_2246.field_10119, ModBlocks.OAK_BEAM);
            entries.addAfter(class_2246.field_10071, ModBlocks.SPRUCE_BEAM);
            entries.addAfter(class_2246.field_10257, ModBlocks.BIRCH_BEAM);
            entries.addAfter(class_2246.field_10617, ModBlocks.JUNGLE_BEAM);
            entries.addAfter(class_2246.field_10031, ModBlocks.ACACIA_BEAM);
            entries.addAfter(class_2246.field_10500, ModBlocks.DARK_OAK_BEAM);
            entries.addAfter(class_2246.field_37564, ModBlocks.MANGROVE_BEAM);
            entries.addAfter(class_2246.field_42746, ModBlocks.CHERRY_BEAM);
            entries.addAfter(class_2246.field_40292, ModBlocks.BAMBOO_BEAM);
            entries.addAfter(class_2246.field_22128, ModBlocks.CRIMSON_BEAM);
            entries.addAfter(class_2246.field_22129, ModBlocks.WARPED_BEAM);
        });
    }
}
