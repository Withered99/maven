package net.withered.artisansandmillwork.compat.jei;

import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.ingredient.IRecipeSlotsView;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.withered.artisansandmillwork.ArtisansAndMillwork;
import net.withered.artisansandmillwork.block.ModBlocks;
import net.withered.artisansandmillwork.item.crafting.MillingTableRecipe;

public class MillingRecipeCategory implements IRecipeCategory<MillingTableRecipe> {
    public static final class_2960 UID = class_2960.method_60655(ArtisansAndMillwork.MOD_ID, "milling");
    public static final RecipeType<MillingTableRecipe> MILLING_TYPE = new RecipeType<>(UID, MillingTableRecipe.class);

    private final IDrawable icon;
    private final IDrawable slotDrawable;
    private final IDrawable outputSlotDrawable;
    private final IDrawable arrow;

    public MillingRecipeCategory(IGuiHelper helper) {
        this.icon = helper.createDrawableIngredient(VanillaTypes.ITEM_STACK, new class_1799(ModBlocks.MILLING_TABLE));
        this.slotDrawable = helper.getSlotDrawable();
        this.outputSlotDrawable = helper.getOutputSlot();
        this.arrow = helper.getRecipeArrow();
    }

    @Override
    public RecipeType<MillingTableRecipe> getRecipeType() {
        return MILLING_TYPE;
    }

    @Override
    public class_2561 getTitle() {
        return class_2561.method_43471("container.artisansandmillwork.milling");
    }

    @Override
    public int getWidth() {
        return 116;
    }

    @Override
    public int getHeight() {
        return 34;
    }

    @Override
    public void draw(MillingTableRecipe recipe, IRecipeSlotsView recipeSlotsView, class_332 guiGraphics, double mouseX, double mouseY) {
        this.slotDrawable.draw(guiGraphics, 17, 8);
        this.arrow.draw(guiGraphics, 41, 9);
        this.outputSlotDrawable.draw(guiGraphics, 73, 4);
    }

    @Override
    public IDrawable getIcon() {
        return this.icon;
    }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, MillingTableRecipe recipe, IFocusGroup focuses) {
        builder.addSlot(RecipeIngredientRole.INPUT, 18, 9)
                .addIngredients(recipe.method_8117().get(0));

        assert class_310.method_1551().field_1687 != null;
        builder.addSlot(RecipeIngredientRole.OUTPUT, 78, 9)
                .addItemStack(recipe.method_8110(class_310.method_1551().field_1687.method_30349()));
    }
}
