package net.withered.artisansandmillwork.item.crafting;

import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3972;
import net.minecraft.class_7923;
import net.withered.artisansandmillwork.ArtisansAndMillwork;

public class ModRecipeSerializers {
    public static final class_1865<MillingTableRecipe> MILLING = register(
            "milling",
            new class_3972.class_3973<>(MillingTableRecipe::new) {}
    );

    private static <S extends class_1865<T>, T extends class_1860<?>> S register(String name, S serializer) {
        class_2960 id = class_2960.method_60655(ArtisansAndMillwork.MOD_ID, name);
        return class_2378.method_10230(class_7923.field_41189, id, serializer);
    }

    public static void init() {}
}
