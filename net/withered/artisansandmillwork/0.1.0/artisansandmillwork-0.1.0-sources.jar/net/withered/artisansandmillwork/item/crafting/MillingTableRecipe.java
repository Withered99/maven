package net.withered.artisansandmillwork.item.crafting;

import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_3956;
import net.minecraft.class_3972;
import net.minecraft.class_9696;
import net.withered.artisansandmillwork.block.ModBlocks;

public class MillingTableRecipe extends class_3972 {

    public MillingTableRecipe(String group, class_1856 ingredient, class_1799 result) {
        super(ModRecipeTypes.MILLING, ModRecipeSerializers.MILLING, group, ingredient, result);
    }

    @Override
    public boolean matches(class_9696 input, class_1937 level) {
        return this.field_17642.method_8093(input.comp_2676());
    }

    @Override
    public class_1799 method_17447() {
        return new class_1799(ModBlocks.MILLING_TABLE);
    }

    @Override
    public class_1865<?> method_8119() {
        return ModRecipeSerializers.MILLING;
    }

    @Override
    public class_3956<?> method_17716() {
        return ModRecipeTypes.MILLING;
    }
}
