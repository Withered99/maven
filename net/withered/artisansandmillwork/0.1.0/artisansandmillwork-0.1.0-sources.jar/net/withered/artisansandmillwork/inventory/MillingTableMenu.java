package net.withered.artisansandmillwork.inventory;

import com.google.common.collect.Lists;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1731;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3914;
import net.minecraft.class_3915;
import net.minecraft.class_8786;
import net.minecraft.class_9696;
import net.minecraft.world.inventory.*;
import net.withered.artisansandmillwork.block.ModBlocks;
import net.withered.artisansandmillwork.item.crafting.MillingTableRecipe;
import net.withered.artisansandmillwork.item.crafting.ModRecipeTypes;

import java.util.List;

public class MillingTableMenu extends class_1703 {
    public static final int INPUT_SLOT = 0;
    public static final int RESULT_SLOT = 1;
    private static final int INV_SLOT_START = 2;
    private static final int INV_SLOT_END = 29;
    private static final int USE_ROW_SLOT_START = 29;
    private static final int USE_ROW_SLOT_END = 38;

    private final class_3914 access;
    private final class_3915 selectedRecipeIndex = class_3915.method_17403();
    private final class_1937 level;
    private List<class_8786<MillingTableRecipe>> recipes = Lists.newArrayList();
    private class_1799 input = class_1799.field_8037;
    long lastSoundTime;
    final class_1735 inputSlot;
    final class_1735 resultSlot;
    Runnable slotUpdateListener = () -> {};
    public final class_1263 container = new class_1277(1) {
        @Override
        public void method_5431() {
            super.method_5431();
            MillingTableMenu.this.method_7609(this);
            MillingTableMenu.this.slotUpdateListener.run();
        }
    };
    final class_1731 resultContainer = new class_1731();

    public MillingTableMenu(int containerId, class_1661 playerInventory) {
        this(containerId, playerInventory, class_3914.field_17304);
    }

    public MillingTableMenu(int containerId, class_1661 playerInventory, final class_3914 access) {
        super(ModMenuTypes.MILLING_TABLE, containerId);
        this.access = access;
        this.level = playerInventory.field_7546.method_37908();

        this.inputSlot = this.method_7621(new class_1735(this.container, 0, 20, 33));
        this.resultSlot = this.method_7621(new class_1735(this.resultContainer, 1, 143, 33) {
            @Override
            public boolean method_7680(class_1799 stack) {
                return false;
            }

            @Override
            public void method_7667(class_1657 player, class_1799 stack) {
                stack.method_7982(player.method_37908(), player, stack.method_7947());
                MillingTableMenu.this.resultContainer.method_7664(player, this.getRelevantItems());
                class_1799 remaining = MillingTableMenu.this.inputSlot.method_7671(1);
                if (!remaining.method_7960()) {
                    MillingTableMenu.this.setupResultSlot();
                }

                access.method_17393((level, pos) -> {
                    long gameTime = level.method_8510();
                    if (MillingTableMenu.this.lastSoundTime != gameTime) {
                        level.method_8396(null, pos, class_3417.field_17710, class_3419.field_15245, 1.0F, 1.0F);
                        MillingTableMenu.this.lastSoundTime = gameTime;
                    }
                });
                super.method_7667(player, stack);
            }

            private List<class_1799> getRelevantItems() {
                return List.of(MillingTableMenu.this.inputSlot.method_7677());
            }
        });

        for (int row = 0; row < 3; ++row) {
            for (int col = 0; col < 9; ++col) {
                this.method_7621(new class_1735(playerInventory, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
            }
        }

        for (int col = 0; col < 9; ++col) {
            this.method_7621(new class_1735(playerInventory, col, 8 + col * 18, 142));
        }

        this.method_17362(this.selectedRecipeIndex);
    }

    public int getSelectedRecipeIndex() {
        return this.selectedRecipeIndex.method_17407();
    }

    public List<class_8786<MillingTableRecipe>> getRecipes() {
        return this.recipes;
    }

    public int getNumRecipes() {
        return this.recipes.size();
    }

    public boolean hasInputItem() {
        return this.inputSlot.method_7681() && !this.recipes.isEmpty();
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return method_17695(this.access, player, ModBlocks.MILLING_TABLE);
    }

    @Override
    public boolean method_7604(class_1657 player, int id) {
        if (this.isValidRecipeIndex(id)) {
            this.selectedRecipeIndex.method_17404(id);
            this.setupResultSlot();
        }
        return true;
    }

    private boolean isValidRecipeIndex(int recipeIndex) {
        return recipeIndex >= 0 && recipeIndex < this.recipes.size();
    }

    @Override
    public void method_7609(class_1263 inventory) {
        class_1799 stack = this.inputSlot.method_7677();
        if (!stack.method_31574(this.input.method_7909())) {
            this.input = stack.method_7972();
            this.setupRecipeList(inventory, stack);
        }
    }

    private void setupRecipeList(class_1263 container, class_1799 stack) {
        this.recipes.clear();
        this.selectedRecipeIndex.method_17404(-1);
        this.resultSlot.method_7673(class_1799.field_8037);
        if (!stack.method_7960()) {
            this.recipes = this.level.method_8433().method_17877(
                    ModRecipeTypes.MILLING,
                    new class_9696(stack),
                    this.level
            );
        }
    }

    void setupResultSlot() {
        if (!this.recipes.isEmpty() && this.isValidRecipeIndex(this.selectedRecipeIndex.method_17407())) {
            class_8786<MillingTableRecipe> holder = this.recipes.get(this.selectedRecipeIndex.method_17407());
            class_1799 result = holder.comp_1933().method_59998(new class_9696(this.container.method_5438(0)), this.level.method_30349());
            if (result.method_45435(this.level.method_45162())) {
                this.resultContainer.method_7662(holder);
                this.resultSlot.method_7673(result);
            } else {
                this.resultSlot.method_7673(class_1799.field_8037);
            }
        } else {
            this.resultSlot.method_7673(class_1799.field_8037);
        }
        this.method_7623();
    }

    public void registerUpdateListener(Runnable listener) {
        this.slotUpdateListener = listener;
    }

    @Override
    public boolean method_7613(class_1799 stack, class_1735 slot) {
        return slot.field_7871 != this.resultContainer && super.method_7613(stack, slot);
    }

    @Override
    public class_1799 method_7601(class_1657 player, int index) {
        class_1799 copy = class_1799.field_8037;
        class_1735 slot = this.field_7761.get(index);
        if (slot != null && slot.method_7681()) {
            class_1799 slotStack = slot.method_7677();
            class_1792 item = slotStack.method_7909();
            copy = slotStack.method_7972();
            if (index == 1) {
                item.method_54465(slotStack, player.method_37908(), player);
                if (!this.method_7616(slotStack, INV_SLOT_START, USE_ROW_SLOT_END, true)) {
                    return class_1799.field_8037;
                }
                slot.method_7670(slotStack, copy);
            } else if (index == 0) {
                if (!this.method_7616(slotStack, INV_SLOT_START, USE_ROW_SLOT_END, false)) {
                    return class_1799.field_8037;
                }
            } else if (this.level.method_8433().method_8132(ModRecipeTypes.MILLING, new class_9696(slotStack), this.level).isPresent()) {
                if (!this.method_7616(slotStack, 0, 1, false)) {
                    return class_1799.field_8037;
                }
            } else if (index >= INV_SLOT_START && index < INV_SLOT_END) {
                if (!this.method_7616(slotStack, USE_ROW_SLOT_START, USE_ROW_SLOT_END, false)) {
                    return class_1799.field_8037;
                }
            } else if (index >= USE_ROW_SLOT_START && index < USE_ROW_SLOT_END && !this.method_7616(slotStack, INV_SLOT_START, INV_SLOT_END, false)) {
                return class_1799.field_8037;
            }

            if (slotStack.method_7960()) {
                slot.method_53512(class_1799.field_8037);
            }

            slot.method_7668();
            if (slotStack.method_7947() == copy.method_7947()) {
                return class_1799.field_8037;
            }

            slot.method_7667(player, slotStack);
            this.method_7623();
        }
        return copy;
    }

    @Override
    public void method_7595(class_1657 player) {
        super.method_7595(player);
        this.resultContainer.method_5441(1);
        this.access.method_17393((level, pos) -> this.method_7607(player, this.container));
    }
}
