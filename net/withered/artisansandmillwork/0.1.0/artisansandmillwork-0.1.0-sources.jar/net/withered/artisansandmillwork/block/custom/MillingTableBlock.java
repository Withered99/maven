package net.withered.artisansandmillwork.block.custom;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_10;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2753;
import net.minecraft.class_3726;
import net.minecraft.class_3908;
import net.minecraft.class_3914;
import net.minecraft.class_3965;
import net.minecraft.class_4970;
import net.minecraft.class_747;
import net.minecraft.world.level.block.*;
import net.withered.artisansandmillwork.inventory.MillingTableMenu;
import org.jetbrains.annotations.Nullable;

public class MillingTableBlock extends class_2248 {
    public static final MapCodec<MillingTableBlock> CODEC = method_54094(MillingTableBlock::new);
    private static final class_2561 CONTAINER_TITLE = class_2561.method_43471("container.artisansandmillwork.milling_table");
    public static final class_2753 FACING = class_2383.field_11177;
    protected static final class_265 SHAPE = class_2248.method_9541(0.0, 0.0, 0.0, 16.0, 9.0, 16.0);

    @Override
    public MapCodec<MillingTableBlock> method_53969() {
        return field_46280;
    }

    public MillingTableBlock(class_4970.class_2251 properties) {
        super(properties);
        this.method_9590(this.field_10647.method_11664().method_11657(FACING, class_2350.field_11043));
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        return this.method_9564().method_11657(FACING, context.method_8042().method_10153());
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 level, class_2338 pos, class_1657 player, class_3965 hitResult) {
        if (level.field_9236) {
            return class_1269.field_5812;
        } else {
            player.method_17355(state.method_26196(level, pos));
            return class_1269.field_21466;
        }
    }

    @Nullable
    @Override
    protected class_3908 method_17454(class_2680 state, class_1937 level, class_2338 pos) {
        return new class_747(
                (containerId, inventory, player) -> new MillingTableMenu(containerId, inventory, class_3914.method_17392(level, pos)),
                CONTAINER_TITLE
        );
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 level, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    protected boolean method_9526(class_2680 state) {
        return true;
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    protected class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    protected class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }

    @Override
    protected boolean method_9516(class_2680 state, class_10 pathComputationType) {
        return false;
    }
}
