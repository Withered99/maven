package net.withered.artisansandmillwork.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2741;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4925;
import net.minecraft.class_4926;
import net.minecraft.class_4935;
import net.minecraft.class_4936;
import net.minecraft.class_4942;
import net.minecraft.class_4944;
import net.minecraft.class_4945;
import net.withered.artisansandmillwork.ArtisansAndMillwork;
import net.withered.artisansandmillwork.block.ModBlocks;

import java.util.Optional;

public class ModModelProvider extends FabricModelProvider {
    private static final class_4942 BEAM_TEMPLATE = new class_4942(
            Optional.of(class_2960.method_60655(ArtisansAndMillwork.MOD_ID, "block/template_beam")),
            Optional.empty(),
            class_4945.field_23018,
            class_4945.field_23013
    );
    private static final class_4942 BRACE_TEMPLATE = new class_4942(
            Optional.of(class_2960.method_60655(ArtisansAndMillwork.MOD_ID, "block/template_brace")),
            Optional.empty(),
            class_4945.field_23018,
            class_4945.field_23013
    );

    public ModModelProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(class_4910 generators) {
        registerBeam(generators, ModBlocks.OAK_BEAM, class_2246.field_10161);
        registerBeam(generators, ModBlocks.SPRUCE_BEAM, class_2246.field_9975);
        registerBeam(generators, ModBlocks.BIRCH_BEAM, class_2246.field_10148);
        registerBeam(generators, ModBlocks.JUNGLE_BEAM, class_2246.field_10334);
        registerBeam(generators, ModBlocks.ACACIA_BEAM, class_2246.field_10218);
        registerBeam(generators, ModBlocks.DARK_OAK_BEAM, class_2246.field_10075);
        registerBeam(generators, ModBlocks.MANGROVE_BEAM, class_2246.field_37577);
        registerBeam(generators, ModBlocks.CHERRY_BEAM, class_2246.field_42751);
        registerBeam(generators, ModBlocks.BAMBOO_BEAM, class_2246.field_41072);
        registerBeam(generators, ModBlocks.CRIMSON_BEAM, class_2246.field_22126);
        registerBeam(generators, ModBlocks.WARPED_BEAM, class_2246.field_22127);
    }

    private void registerBeam(class_4910 generators, class_2248 beamBlock, class_2248 textureSource) {
        class_4944 textures = new class_4944()
                .method_25868(class_4945.field_23018, class_4944.method_25860(textureSource))
                .method_25868(class_4945.field_23013, class_4944.method_25860(textureSource));

        class_2960 modelId = BEAM_TEMPLATE.method_25846(beamBlock, textures, generators.field_22831);

        generators.field_22830.accept(
                class_4925.method_25769(beamBlock)
                        .method_25775(class_4926.method_25783(class_2741.field_12496)
                                .method_25793(class_2350.class_2351.field_11052, class_4935.method_25824()
                                        .method_25828(class_4936.field_22887, modelId))
                                .method_25793(class_2350.class_2351.field_11051, class_4935.method_25824()
                                        .method_25828(class_4936.field_22887, modelId)
                                        .method_25828(class_4936.field_22885, class_4936.class_4937.field_22891))
                                .method_25793(class_2350.class_2351.field_11048, class_4935.method_25824()
                                        .method_25828(class_4936.field_22887, modelId)
                                        .method_25828(class_4936.field_22885, class_4936.class_4937.field_22891)
                                        .method_25828(class_4936.field_22886, class_4936.class_4937.field_22891))
                        )
        );
        generators.method_25623(beamBlock, modelId);
    }

    @Override
    public void generateItemModels(class_4915 itemModelGenerators) {
    }
}
