package net.withered.artisansandmillwork.inventory;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7701;
import net.minecraft.class_7923;
import net.withered.artisansandmillwork.ArtisansAndMillwork;

public class ModMenuTypes {
    public static final class_3917<MillingTableMenu> MILLING_TABLE = class_2378.method_10230(
            class_7923.field_41187,
            class_2960.method_60655(ArtisansAndMillwork.MOD_ID, "milling_table"),
            new class_3917<>(MillingTableMenu::new, class_7701.field_40182)
    );

    public static void init() {}
}
