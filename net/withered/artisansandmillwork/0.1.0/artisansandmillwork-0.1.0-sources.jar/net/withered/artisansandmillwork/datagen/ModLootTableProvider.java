package net.withered.artisansandmillwork.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_7225;
import net.withered.artisansandmillwork.block.ModBlocks;

import java.util.concurrent.CompletableFuture;

public class ModLootTableProvider extends FabricBlockLootTableProvider {
    public ModLootTableProvider(FabricDataOutput dataOutput, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataOutput, registryLookup);
    }

    @Override
    public void method_10379() {
        method_46025(ModBlocks.MILLING_TABLE);

        method_46025(ModBlocks.OAK_BEAM);
        method_46025(ModBlocks.SPRUCE_BEAM);
        method_46025(ModBlocks.BIRCH_BEAM);
        method_46025(ModBlocks.JUNGLE_BEAM);
        method_46025(ModBlocks.ACACIA_BEAM);
        method_46025(ModBlocks.DARK_OAK_BEAM);
        method_46025(ModBlocks.MANGROVE_BEAM);
        method_46025(ModBlocks.CHERRY_BEAM);
        method_46025(ModBlocks.BAMBOO_BEAM);
        method_46025(ModBlocks.CRIMSON_BEAM);
        method_46025(ModBlocks.WARPED_BEAM);
    }
}
