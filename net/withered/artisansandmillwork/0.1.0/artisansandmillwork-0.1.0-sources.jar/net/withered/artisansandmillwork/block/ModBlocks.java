package net.withered.artisansandmillwork.block;

import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_7923;
import net.withered.artisansandmillwork.ArtisansAndMillwork;
import net.withered.artisansandmillwork.block.custom.BeamBlock;
import net.withered.artisansandmillwork.block.custom.MillingTableBlock;

public class ModBlocks {
    public static final class_2248 MILLING_TABLE = registerBlock("milling_table",
            new MillingTableBlock(class_4970.class_2251.method_9630(class_2246.field_16335)
                    .method_22488()
                    .method_29292()));

    public static final class_2248 OAK_BEAM = registerBlock("oak_beam", new BeamBlock(class_4970.class_2251.method_9630(class_2246.field_10161).method_22488()));
    public static final class_2248 SPRUCE_BEAM = registerBlock("spruce_beam", new BeamBlock(class_4970.class_2251.method_9630(class_2246.field_10161).method_22488()));
    public static final class_2248 BIRCH_BEAM = registerBlock("birch_beam", new BeamBlock(class_4970.class_2251.method_9630(class_2246.field_10161).method_22488()));
    public static final class_2248 JUNGLE_BEAM = registerBlock("jungle_beam", new BeamBlock(class_4970.class_2251.method_9630(class_2246.field_10161).method_22488()));
    public static final class_2248 ACACIA_BEAM = registerBlock("acacia_beam", new BeamBlock(class_4970.class_2251.method_9630(class_2246.field_10161).method_22488()));
    public static final class_2248 DARK_OAK_BEAM = registerBlock("dark_oak_beam", new BeamBlock(class_4970.class_2251.method_9630(class_2246.field_10161).method_22488()));
    public static final class_2248 MANGROVE_BEAM = registerBlock("mangrove_beam", new BeamBlock(class_4970.class_2251.method_9630(class_2246.field_10161).method_22488()));
    public static final class_2248 CHERRY_BEAM = registerBlock("cherry_beam", new BeamBlock(class_4970.class_2251.method_9630(class_2246.field_10161).method_22488()));
    public static final class_2248 BAMBOO_BEAM = registerBlock("bamboo_beam", new BeamBlock(class_4970.class_2251.method_9630(class_2246.field_10161).method_22488()));
    public static final class_2248 CRIMSON_BEAM = registerBlock("crimson_beam", new BeamBlock(class_4970.class_2251.method_9630(class_2246.field_10161).method_22488()));
    public static final class_2248 WARPED_BEAM = registerBlock("warped_beam", new BeamBlock(class_4970.class_2251.method_9630(class_2246.field_10161).method_22488()));

    private static class_2248 registerBlock(String name, class_2248 block) {
        registerBlockItem(name, block);
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(ArtisansAndMillwork.MOD_ID, name), block);
    }

    private static void registerBlockItem(String name, class_2248 block) {
        class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(ArtisansAndMillwork.MOD_ID, name),
                new class_1747(block, new class_1792.class_1793()));
    }

    public static void init() {
    }
}
